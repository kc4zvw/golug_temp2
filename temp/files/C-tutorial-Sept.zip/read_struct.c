//
// $Id:$
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

#define MAXNUM 2000
#define RECCNT 10
#define DATAFILE "records.dat"

/* function prototypes */

int display_record(int);

/* user defined data types */

struct record_t
{
	char name[60];
	unsigned long num1;
	float num2;
} records[RECCNT];


int main()
{
	FILE *filein;
	int i, j;
	
	srandom(0);

	printf("The size of record structure is %ld.\n", sizeof(records[0]));

	filein = fopen(DATAFILE, "rb");

	if (filein == NULL) {
		fprintf(stderr, "Cannot open file %s for input.\n", DATAFILE);
		exit(3);
	}

	for (int rc = 0; rc < RECCNT; rc++) {
		/* what */
		printf("Reading record: %d\n", rc + 1);
		fread(&records[rc], sizeof(records[rc]), 1, filein);
		i = display_record(rc);
	}

	fclose(filein);

	return 0;
}

int display_record(int i)
{
	printf("The name field is %s.\n", records[i].name);
	printf("num1 is %ld and num2 is %5.3lf\n", records[i].num1, records[i].num2);

	return 0;
}

/* End of File */
