//
// $Id:$
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>
#include <time.h>

#define MAXNUM 2000
#define RECCNT 10
#define DATAFILE "records.dat"

/* function prototypes */

int init_record(int);

/* user defined data types */

struct record_t
{
	char name[60];
	unsigned long num1;
	float num2;
} records[RECCNT];


int main()
{
	FILE *fileout;
	int i, j;
	
	srandom(0);

	printf("The size of record structure is %ld.\n", sizeof(records));

	fileout = fopen(DATAFILE, "wb");

	if (fileout == NULL) {
		fprintf(stderr, "Cannot open file %s for output.\n", DATAFILE);
		exit(3);
	}

	for (int rc = 0; rc < RECCNT; rc++) {
		/* what */
		printf("Writing record: %d\n", rc + 1);
		i = init_record(rc);
		printf("num1 is %ld and num2 is %5.3lf\n", records[rc].num1, records[rc].num2);
		fwrite(&records[rc], sizeof(records[rc]), 1, fileout);
	}

	fclose(fileout);

	return 0;
}

int init_record(int i)
{
	strcpy(records[i].name, "123456789A123456789B123456789C123456789_");
	records[i].num1 = (unsigned long) floor((random() * MAXNUM) + 1);
	records[i].num2 = (float) random() * 3.0;

	return 0;
}

/* End of File */
